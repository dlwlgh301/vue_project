module.exports = {
    extends: 'eslint:recommended',
    rules: {
        // "no-console":  process.env.NODE_ENV === 'production' ? 'error' : 'off',
        'no-console': 'off'
    }
};
