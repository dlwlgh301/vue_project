module.exports = {
    transpileDependencies: ['vuetify']
};
