<template>
    <div class="user" id="error">
        <div class="wrapC " style="padding-top: 100px;">
            <h1>에러가 발생했어요!<br /></h1>
            <button class="btn btn--back btn--login">
                이전화면으로 돌아가기
            </button>
        </div>
    </div>
</template>
